import './App.css';
import { Routes, Route } from 'react-router-dom';
// import AuthPage from './pages/auth/Index';
// import Dashboard from './pages/dashboard/Index';
// import Navbar from './components/navbar/Index';
// import NotFound from './pages/NotFound';
// import ProtectedRoutes from './components/protectedRoutes';
import ProtectedRoutes from './components/ProtectedRoutes';
import Auth from './pages/Auth';

function App() {
  return (
    <>
      <h2>My App</h2>
      <Routes>
        <Route path='/auth' element={<Auth />} />
        <Route element={<ProtectedRoutes/>}>
          {/* <Route path='/dashboard' element={<Dashboard />} /> */}
        </Route>
        {/* <Route path='*' element={<NotFound />} /> */}
      </Routes>
    </>
  );
}

export default App;
